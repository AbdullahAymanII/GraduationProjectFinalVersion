package com.backend.model.user.constants;

public enum Role {
    USER,
    ADMIN,
}
