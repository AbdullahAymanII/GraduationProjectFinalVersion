package com.backend.model.user.constants;

public enum AccountSource {
    GITHUB,
    GOOGLE,
    CODE_EDITOR
}